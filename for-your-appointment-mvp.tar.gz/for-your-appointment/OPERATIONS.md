# Operations Manual & API Guide

This document provides comprehensive documentation for system administrators and developers operating the Prize Bond Intelligence System in production environments.

## System Architecture Overview

The Prize Bond Intelligence System is built as a full-stack Next.js application with server-side rendering and API-driven architecture. The frontend communicates exclusively with backend API routes through JSON over HTTP. All business logic resides on the server, ensuring data consistency and security.

The architecture consists of three primary layers. The presentation layer implements a React-based user interface rendered server-side through Next.js with client-side hydration for interactivity. The API layer consists of Next.js API routes that handle all data operations and business logic. The data layer uses Supabase as a managed PostgreSQL service for reliable data persistence.

This layered architecture ensures separation of concerns, facilitates testing and scaling, and provides security boundaries between the client and data layers. All modifications to data pass through validated API endpoints, preventing direct database access from the browser.

## API Endpoints Reference

### POST /api/add-bond

This endpoint creates a new prize bond entry in the bonds table. The endpoint accepts a JSON request body containing the bond serial number, 6-digit bond number, and denomination amount.

Request parameters include serial as a string containing the bond's serial identifier, number as a string containing exactly 6 digits, and denomination as an integer representing the investment amount in Pakistani Rupees.

A successful request returns HTTP status 201 with a JSON response containing success true and the created bond object including the auto-generated UUID id field.

Error responses return appropriate HTTP status codes including 400 for missing required fields or invalid format, 409 if the bond number already exists in the database, and 500 for unexpected server errors.

Example request:

```bash
curl -X POST http://localhost:3000/api/add-bond \
  -H "Content-Type: application/json" \
  -d '{
    "serial": "ABC123",
    "number": "456789",
    "denomination": 1500
  }'
```

Example response:

```json
{
  "success": true,
  "bond": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "serial": "ABC123",
    "number": "456789",
    "denomination": 1500,
    "created_at": "2024-01-15T10:30:00.000Z"
  }
}
```

### GET /api/bonds

This endpoint retrieves all bonds currently stored in the system, sorted by creation date in descending order with the most recently added bonds appearing first.

The endpoint accepts no request parameters and returns a JSON array of all bond objects containing id, serial, number, denomination, purchase_date, and created_at fields.

A successful request returns HTTP status 200 with an array of bond objects.

Example request:

```bash
curl http://localhost:3000/api/bonds
```

Example response:

```json
{
  "success": true,
  "bonds": [
    {
      "id": "550e8400-e29b-41d4-a716-446655440000",
      "serial": "ABC123",
      "number": "456789",
      "denomination": 1500,
      "created_at": "2024-01-15T10:30:00.000Z"
    }
  ]
}
```

### DELETE /api/bonds/[id]

This endpoint permanently removes a bond from the system. The endpoint requires the bond's UUID as a path parameter. Deletion is permanent and cannot be reversed without database recovery from backups.

A successful request returns HTTP status 200 with a success message.

Error responses return 400 if the bond ID is missing or invalid, 404 if the bond does not exist, and 500 for unexpected server errors.

Example request:

```bash
curl -X DELETE http://localhost:3000/api/bonds/550e8400-e29b-41d4-a716-446655440000
```

### POST /api/upload-pdf

This endpoint processes a lottery draw result PDF and extracts winning numbers. The endpoint accepts multipart form data containing a PDF file, draw name, and draw date.

Form parameters include file as the PDF file to process with maximum size of 10MB, draw as a string containing the draw identifier, and drawDate as an ISO 8601 date string.

A successful request returns HTTP status 201 with details about the extracted numbers, number of bonds that matched, and total winnings amount.

The endpoint automatically classifies extracted numbers as first prize (first number), second prizes (next 3 numbers), and third prizes (remaining numbers). Standard prize amounts are applied unless customized in the API route.

Example request using curl:

```bash
curl -X POST http://localhost:3000/api/upload-pdf \
  -F "file=@result.pdf" \
  -F "draw=Draw 2024-Jan" \
  -F "drawDate=2024-01-15"
```

Example response:

```json
{
  "success": true,
  "message": "Processed 1004 prize numbers. Found 2 matching bonds.",
  "data": {
    "resultsCount": 1004,
    "matchCount": 2,
    "totalWins": 40000,
    "parsed": {
      "firstPrize": "123456",
      "secondPrizes": 3,
      "thirdPrizes": 1000
    }
  }
}
```

### GET /api/check-results

This endpoint retrieves all matching bonds across all draws. The endpoint performs a cross-reference between the bonds table and results table, returning all matches found.

The endpoint accepts no parameters and returns an array of matches with bond information and prize details.

Example request:

```bash
curl http://localhost:3000/api/check-results
```

Example response:

```json
{
  "success": true,
  "matches": [
    {
      "bondId": "550e8400-e29b-41d4-a716-446655440000",
      "bondNumber": "456789",
      "prizeType": "third",
      "amount": 40000
    }
  ],
  "count": 1
}
```

### GET /api/dashboard

This endpoint retrieves comprehensive dashboard statistics and historical data. The endpoint aggregates all available data to provide system overview metrics and recent activity.

The endpoint returns statistics including total bonds, total investment amount, total winnings, ROI percentage, and winning bond count. It also returns draw history and details of the ten most recent results.

Example request:

```bash
curl http://localhost:3000/api/dashboard
```

Example response:

```json
{
  "success": true,
  "stats": {
    "totalBonds": 10,
    "totalInvestment": 25000,
    "totalWins": 40000,
    "roi": 160.00,
    "winCount": 1
  },
  "history": [
    {
      "draw": "Draw 2024-Jan",
      "drawDate": "2024-01-15T00:00:00.000Z",
      "totalWins": 1,
      "totalAmount": 40000
    }
  ],
  "latestResults": []
}
```

## Common Workflows

### Workflow 1: Adding a New Bond

A user wishes to add a prize bond to their portfolio. First, navigate to the Add Bond page in the user interface. Enter the bond serial number as it appears on the physical bond certificate. Enter the bond number as exactly 6 digits without spaces or formatting. Select the denomination amount that matches the purchase price of the bond.

Click the Add Bond button to submit the form. The system validates the input and creates the bond entry in the database. If successful, a confirmation message appears and the new bond is immediately visible in the bonds list. If an error occurs, an error message indicates the specific issue, typically that the bond number already exists.

### Workflow 2: Processing a Monthly Draw Result

At the beginning of each month, the lottery authority releases draw result PDFs. Download the official PDF from the authority's website. In the Prize Bond Intelligence System, navigate to the Upload Result page.

Enter the draw identifier in the format "Draw 2024-Jan" or "Draw 202401" depending on your preference. Select the date the draw was held. Click the file upload area and select the downloaded PDF file. Click Upload and Process to begin processing.

The system extracts all 6-digit numbers from the PDF, classifies them as first, second, and third prizes based on position, and compares them against your bond inventory. Within seconds, you see a summary showing how many numbers were extracted and how many of your bonds matched prizes. The dashboard automatically updates to reflect any new winnings.

### Workflow 3: Reviewing Dashboard Statistics

Navigate to the Dashboard page to view your current statistics. The stat cards display your total bond count, total investment amount, total winnings across all draws, your return on investment percentage, and the number of bonds that have won prizes.

The winning bonds table displays all bonds that matched prize numbers, showing the bond number, draw in which it won, prize tier, and amount won. The draw history on the right shows aggregated results by draw, allowing you to see performance across each monthly draw.

Use the dashboard to assess your portfolio performance, identify trends, and determine whether to continue investing in additional bonds.

### Workflow 4: Adding Bonds in Bulk

If you have multiple bonds to add, use the Add Bond interface repeatedly. Enter each bond's information and click Add Bond. Each bond is immediately stored and visible in the bonds list. The system prevents duplicate entries, so if a bond number already exists, you will receive a clear error message.

For technical users wishing to bulk import bonds from a spreadsheet, export the data as JSON in the format expected by the API and use a bulk import script to process multiple bonds in a single operation.

### Workflow 5: Investigating Missing Matches

If you believe a bond should have won but it does not appear in the dashboard, first verify that the bond number was entered correctly when adding the bond. Open the bond detail and confirm the 6-digit number is exactly correct.

Next, verify that the draw result PDF was processed correctly. Check the upload summary to confirm that the expected numbers were extracted from the PDF. If numbers appear missing, try re-uploading the same PDF or downloading the result from an alternative source.

If the bond number is correct and appears in the extracted numbers, the issue may be a data synchronization problem. Try refreshing your browser to force the dashboard to reload fresh data from the server.

## Monitoring and Maintenance

### Database Size Monitoring

Check your Supabase project's database size regularly by accessing your project settings and noting the Storage usage. For production systems, monitor growth rate to identify if data is accumulating faster than expected.

Query the system to count records in each table using SQL:

```sql
SELECT 'bonds' AS table_name, COUNT(*) AS record_count FROM bonds
UNION ALL
SELECT 'results', COUNT(*) FROM results
UNION ALL
SELECT 'history', COUNT(*) FROM history;
```

If the results table exceeds 100,000 records, consider archiving old draw results to reduce database size and improve query performance.

### Application Performance Monitoring

Monitor your application's performance using your hosting platform's built-in monitoring tools. For Vercel, access the Analytics tab to view response times, error rates, and bandwidth usage.

Monitor the application logs for errors that may indicate performance issues or data problems. Errors related to database timeouts typically indicate that your database needs optimization.

### Security Audits

Periodically verify that your Supabase access keys have not been compromised by checking the API key usage in your Supabase dashboard. If suspicious activity is detected, regenerate your API keys immediately.

Review your application's authentication logs to identify any unauthorized access attempts. Although the current system is single-user, adding authentication in the future would provide additional security.

### Backup Verification

On a monthly basis, download a database backup from Supabase and verify that it can be restored without errors. This ensures that your backup procedures are working correctly and that you can recover data if needed.

Test restoring a backup to a separate test project to verify data integrity and that the application functions correctly with restored data.

## Troubleshooting Guide

### High CPU Usage During PDF Processing

PDF processing with OCR is computationally intensive and uses 100% of available CPU resources for the duration of the operation. This is normal and expected behavior. For large batch processing, stagger PDF uploads to avoid excessive server load.

If CPU usage remains high after PDF processing completes, your server may be running other resource-intensive tasks. Consider using a higher-tier server with more CPU resources.

### Slow API Response Times

If API endpoints respond slowly, first check your database query performance. Use Supabase's query analytics to identify slow queries. Typically, slow response times indicate that a query is scanning entire tables rather than using indexes.

Verify that indexes are in place on the bonds.number and results.number columns. If these indexes are missing, re-run the database initialization script.

If database performance appears normal, the issue may be external. Check your network connectivity and server load.

### PDF Processing Accuracy Issues

If PDF processing consistently misses numbers or extracts incorrect values, your PDFs may be using an uncommon format or layout. Try downloading result PDFs from the official authority source rather than third-party sites.

If accuracy issues persist, examine the raw extracted text by saving the PDF and running the extraction code in isolation. This helps identify whether the issue is with PDF parsing or with number classification logic.

## API Error Codes

The system returns standard HTTP status codes along with descriptive error messages. Status code 200 indicates a successful GET request. Status code 201 indicates successful creation of a new resource. Status code 400 indicates invalid input parameters or malformed requests.

Status code 404 indicates the requested resource does not exist or has been deleted. Status code 409 indicates a conflict, typically a duplicate entry attempt. Status code 500 indicates an unexpected server error requiring investigation.
