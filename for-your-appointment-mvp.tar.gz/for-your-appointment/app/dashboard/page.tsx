'use client';

import { useEffect, useState } from 'react';
import { StatsCards } from '@/components/StatsCards';
import { ResultsTable } from '@/components/ResultsTable';

interface DashboardStats {
  totalBonds: number;
  totalInvestment: number;
  totalWins: number;
  roi: number;
  winCount: number;
}

interface HistoryItem {
  draw: string;
  drawDate: string;
  totalWins: number;
  totalAmount: number;
}

interface Result {
  id: string;
  number: string;
  draw: string;
  prize_type: string;
  amount: number;
  draw_date: string;
}

export default function Dashboard() {
  const [stats, setStats] = useState<DashboardStats>({
    totalBonds: 0,
    totalInvestment: 0,
    totalWins: 0,
    roi: 0,
    winCount: 0,
  });
  const [results, setResults] = useState<Result[]>([]);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        setIsLoading(true);
        const response = await fetch('/api/dashboard');

        if (!response.ok) {
          throw new Error('Failed to fetch dashboard data');
        }

        const data = await response.json();
        setStats(data.stats);
        setResults(data.latestResults || []);
        setHistory(data.history || []);
      } catch (err: any) {
        setError(err.message || 'An error occurred');
        console.error('Dashboard fetch error:', err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="section-title mb-2">Prize Bond Intelligence Dashboard</h1>
        <p className="text-text-muted">Track your bonds, monitor draws, and calculate returns.</p>
      </div>

      {error && (
        <div className="p-4 bg-red-500/10 border border-red-500/30 text-red-300 rounded-lg">
          {error}
        </div>
      )}

      <StatsCards
        totalBonds={stats.totalBonds}
        totalInvestment={stats.totalInvestment}
        totalWins={stats.totalWins}
        roi={stats.roi}
        winCount={stats.winCount}
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <ResultsTable
            results={results.map((r) => ({
              id: r.id,
              bondNumber: r.number,
              draw: r.draw,
              prizeType: r.prize_type,
              amount: r.amount,
              drawDate: r.draw_date,
            }))}
            isLoading={isLoading}
          />
        </div>

        <div className="card animate-fade-in">
          <h3 className="subsection-title">Draw History</h3>
          {history.length === 0 ? (
            <p className="text-text-muted text-sm">No draw history yet</p>
          ) : (
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {history.map((item, idx) => (
                <div
                  key={idx}
                  className="p-3 bg-dark-bg rounded-lg border border-dark-border hover:border-primary-600/50 transition-colors"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-semibold text-primary-400 text-sm">{item.draw}</p>
                      <p className="text-xs text-text-muted mt-1">
                        {new Date(item.drawDate).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-accent-500 text-sm">
                        {item.totalAmount.toLocaleString()} PKR
                      </p>
                      <p className="text-xs text-text-muted">{item.totalWins} wins</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
