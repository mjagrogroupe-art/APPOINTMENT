'use client';

import { useEffect, useState } from 'react';
import { PDFUpload } from '@/components/PDFUpload';

interface UploadResponse {
  success: boolean;
  message: string;
  data: {
    resultsCount: number;
    matchCount: number;
    totalWins: number;
    parsed: {
      firstPrize: string | null;
      secondPrizes: number;
      thirdPrizes: number;
    };
  };
}

export default function UploadResultPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [lastUpload, setLastUpload] = useState<UploadResponse | null>(null);
  const [error, setError] = useState('');

  const handleUploadPDF = async (file: File, draw: string, drawDate: string) => {
    try {
      setIsLoading(true);
      setError('');
      setSuccessMessage('');

      const formData = new FormData();
      formData.append('file', file);
      formData.append('draw', draw);
      formData.append('drawDate', drawDate);

      const response = await fetch('/api/upload-pdf', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error);
      }

      const data: UploadResponse = await response.json();
      setLastUpload(data);
      setSuccessMessage(data.message);
      setTimeout(() => setSuccessMessage(''), 5000);
    } catch (err: any) {
      setError(err.message || 'Failed to process PDF');
      console.error('Upload error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="section-title mb-2">Upload Draw Results</h1>
        <p className="text-text-muted">
          Upload lottery draw result PDFs to automatically extract prize numbers and match against your bonds.
        </p>
      </div>

      {successMessage && (
        <div className="p-4 bg-accent-500/10 border border-accent-500/30 text-accent-300 rounded-lg animate-fade-in">
          ✓ {successMessage}
        </div>
      )}

      {error && (
        <div className="p-4 bg-red-500/10 border border-red-500/30 text-red-300 rounded-lg animate-fade-in">
          ✗ {error}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div>
          <PDFUpload onUpload={handleUploadPDF} isLoading={isLoading} />
        </div>

        <div className="lg:col-span-2 space-y-6">
          {lastUpload && (
            <div className="card animate-fade-in">
              <h3 className="subsection-title">Last Upload Summary</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-dark-bg rounded-lg border border-dark-border">
                  <p className="text-text-muted text-sm">Prize Numbers Extracted</p>
                  <p className="text-2xl font-bold text-primary-400">
                    {lastUpload.data.resultsCount}
                  </p>
                </div>
                <div className="p-4 bg-dark-bg rounded-lg border border-dark-border">
                  <p className="text-text-muted text-sm">Matching Bonds Found</p>
                  <p className="text-2xl font-bold text-accent-500">
                    {lastUpload.data.matchCount}
                  </p>
                </div>
                <div className="p-4 bg-dark-bg rounded-lg border border-dark-border">
                  <p className="text-text-muted text-sm">Total Winnings</p>
                  <p className="text-2xl font-bold text-accent-500">
                    {lastUpload.data.totalWins.toLocaleString()} PKR
                  </p>
                </div>
                <div className="p-4 bg-dark-bg rounded-lg border border-dark-border">
                  <p className="text-text-muted text-sm">First Prize Found</p>
                  <p className="text-2xl font-bold text-primary-400">
                    {lastUpload.data.parsed.firstPrize ? '✓' : '✗'}
                  </p>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-dark-border">
                <p className="text-xs text-text-muted">
                  <span className="font-semibold">Breakdown:</span> {lastUpload.data.parsed.secondPrizes} 2nd prizes,{' '}
                  {lastUpload.data.parsed.thirdPrizes} 3rd prizes
                </p>
              </div>
            </div>
          )}

          <div className="card">
            <h3 className="subsection-title">How It Works</h3>
            <div className="space-y-4 text-sm text-text-muted">
              <div className="flex gap-3">
                <span className="flex-shrink-0 font-bold text-primary-400">1.</span>
                <p>Download the official lottery draw result PDF from the issuing authority.</p>
              </div>
              <div className="flex gap-3">
                <span className="flex-shrink-0 font-bold text-primary-400">2.</span>
                <p>Enter the draw name (e.g., "Draw 2024-Jan") and select the draw date.</p>
              </div>
              <div className="flex gap-3">
                <span className="flex-shrink-0 font-bold text-primary-400">3.</span>
                <p>Upload the PDF. The system extracts all 6-digit numbers automatically.</p>
              </div>
              <div className="flex gap-3">
                <span className="flex-shrink-0 font-bold text-primary-400">4.</span>
                <p>The first number is classified as 1st Prize, next 3 as 2nd prizes, rest as 3rd prizes.</p>
              </div>
              <div className="flex gap-3">
                <span className="flex-shrink-0 font-bold text-primary-400">5.</span>
                <p>System automatically matches extracted numbers against your bond inventory.</p>
              </div>
              <div className="flex gap-3">
                <span className="flex-shrink-0 font-bold text-primary-400">6.</span>
                <p>Winning bonds appear in your Dashboard with prize type and amount.</p>
              </div>
            </div>
          </div>

          <div className="card">
            <h3 className="subsection-title">Prize Amounts (Standard)</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between p-2 bg-dark-bg rounded">
                <span className="text-text-muted">1st Prize</span>
                <span className="font-bold text-accent-500">7,500,000 PKR</span>
              </div>
              <div className="flex justify-between p-2 bg-dark-bg rounded">
                <span className="text-text-muted">2nd Prize (×3)</span>
                <span className="font-bold text-accent-500">750,000 PKR each</span>
              </div>
              <div className="flex justify-between p-2 bg-dark-bg rounded">
                <span className="text-text-muted">3rd Prize (×1000)</span>
                <span className="font-bold text-accent-500">40,000 PKR each</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
