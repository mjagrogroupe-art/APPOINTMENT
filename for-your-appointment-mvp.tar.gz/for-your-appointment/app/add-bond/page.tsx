'use client';

import { useEffect, useState } from 'react';
import { BondForm } from '@/components/BondForm';
import { BondsList } from '@/components/BondsList';

interface Bond {
  id: string;
  serial: string;
  number: string;
  denomination: number;
}

export default function AddBondPage() {
  const [bonds, setBonds] = useState<Bond[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingList, setIsLoadingList] = useState(true);
  const [successMessage, setSuccessMessage] = useState('');

  const fetchBonds = async () => {
    try {
      setIsLoadingList(true);
      const response = await fetch('/api/bonds');
      if (!response.ok) throw new Error('Failed to fetch bonds');
      const data = await response.json();
      setBonds(data.bonds || []);
    } catch (err) {
      console.error('Error fetching bonds:', err);
    } finally {
      setIsLoadingList(false);
    }
  };

  useEffect(() => {
    fetchBonds();
  }, []);

  const handleAddBond = async (serial: string, number: string, denomination: number) => {
    try {
      setIsLoading(true);
      const response = await fetch('/api/add-bond', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ serial, number, denomination }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error);
      }

      setSuccessMessage(`Bond ${number} added successfully!`);
      setTimeout(() => setSuccessMessage(''), 3000);
      await fetchBonds();
    } catch (err: any) {
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteBond = async (id: string) => {
    try {
      const response = await fetch(`/api/bonds/${id}`, {
        method: 'DELETE',
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error);
      }

      await fetchBonds();
    } catch (err: any) {
      throw err;
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="section-title mb-2">Manage Your Prize Bonds</h1>
        <p className="text-text-muted">
          Add and track all your prize bonds. Enter the bond serial, number, and denomination.
        </p>
      </div>

      {successMessage && (
        <div className="p-4 bg-accent-500/10 border border-accent-500/30 text-accent-300 rounded-lg animate-fade-in">
          ✓ {successMessage}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div>
          <BondForm onSubmit={handleAddBond} isLoading={isLoading} />
        </div>

        <div className="lg:col-span-2">
          <BondsList bonds={bonds} onDelete={handleDeleteBond} isLoading={isLoadingList} />
        </div>
      </div>

      <div className="card">
        <h3 className="subsection-title">Tips for Success</h3>
        <ul className="space-y-2 text-sm text-text-muted">
          <li>✓ Bond numbers must be exactly 6 digits (e.g., 123456)</li>
          <li>✓ Each bond number can only be added once</li>
          <li>✓ Common denominations: 100, 500, 1,500, 5,000, 10,000, 15,000, 25,000 PKR</li>
          <li>✓ Keep your serial numbers for reference</li>
          <li>✓ You can delete bonds by clicking the × button</li>
        </ul>
      </div>
    </div>
  );
}
