import type { Metadata } from 'next';
import Layout from '@/components/Layout';
import './globals.css';

export const metadata: Metadata = {
  title: 'For Your Appointment - Prize Bond Intelligence',
  description: 'Track, analyze, and manage your prize bonds with intelligent matching and ROI tracking.',
  viewport: 'width=device-width, initial-scale=1',
  robots: 'index, follow',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <meta charSet="utf-8" />
        <meta name="theme-color" content="#0f172a" />
      </head>
      <body>
        <Layout>{children}</Layout>
      </body>
    </html>
  );
}
