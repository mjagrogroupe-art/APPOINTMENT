import { NextRequest, NextResponse } from 'next/server';
import { getAllResults, getBonds } from '@/lib/supabase';
import { matchBondsWithResults } from '@/lib/match-logic';

export async function GET(request: NextRequest) {
  try {
    const bonds = await getBonds();
    const allResults = await getAllResults();

    const matches = matchBondsWithResults(bonds, allResults);

    return NextResponse.json(
      {
        success: true,
        matches,
        count: matches.length,
      },
      { status: 200 }
    );
  } catch (error: any) {
    console.error('Error checking results:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to check results' },
      { status: 500 }
    );
  }
}
