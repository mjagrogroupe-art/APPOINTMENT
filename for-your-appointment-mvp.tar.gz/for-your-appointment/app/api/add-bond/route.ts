import { NextRequest, NextResponse } from 'next/server';
import { addBond } from '@/lib/supabase';

export async function POST(request: NextRequest) {
  try {
    const { serial, number, denomination } = await request.json();

    if (!serial || !number || !denomination) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    if (number.length !== 6 || !/^\d+$/.test(number)) {
      return NextResponse.json(
        { error: 'Bond number must be exactly 6 digits' },
        { status: 400 }
      );
    }

    const bond = await addBond(serial, number, denomination);

    return NextResponse.json(
      { success: true, bond },
      { status: 201 }
    );
  } catch (error: any) {
    console.error('Error adding bond:', error);

    if (error.code === '23505') {
      return NextResponse.json(
        { error: 'This bond number already exists' },
        { status: 409 }
      );
    }

    return NextResponse.json(
      { error: error.message || 'Failed to add bond' },
      { status: 500 }
    );
  }
}
