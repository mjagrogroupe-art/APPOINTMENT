import { NextRequest, NextResponse } from 'next/server';
import { deleteBond } from '@/lib/supabase';

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params;

    if (!id) {
      return NextResponse.json(
        { error: 'Bond ID is required' },
        { status: 400 }
      );
    }

    await deleteBond(id);

    return NextResponse.json(
      { success: true, message: 'Bond deleted successfully' },
      { status: 200 }
    );
  } catch (error: any) {
    console.error('Error deleting bond:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to delete bond' },
      { status: 500 }
    );
  }
}
