import { NextRequest, NextResponse } from 'next/server';
import { getBonds } from '@/lib/supabase';

export async function GET(request: NextRequest) {
  try {
    const bonds = await getBonds();
    return NextResponse.json({ success: true, bonds }, { status: 200 });
  } catch (error: any) {
    console.error('Error fetching bonds:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to fetch bonds' },
      { status: 500 }
    );
  }
}
