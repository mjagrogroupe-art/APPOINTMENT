import { NextRequest, NextResponse } from 'next/server';
import { parseDrawResultPDF } from '@/lib/pdf-parser';
import { addResults, getResultsByDraw, upsertHistory, getBonds } from '@/lib/supabase';

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File;
    const draw = formData.get('draw') as string;
    const drawDate = formData.get('drawDate') as string;

    if (!file || !draw || !drawDate) {
      return NextResponse.json(
        { error: 'Missing required fields: file, draw, drawDate' },
        { status: 400 }
      );
    }

    const buffer = Buffer.from(await file.arrayBuffer());
    const parsedResults = await parseDrawResultPDF(buffer);

    if (!parsedResults.firstPrize && parsedResults.secondPrizes.length === 0 && parsedResults.thirdPrizes.length === 0) {
      return NextResponse.json(
        { error: 'No prize numbers could be extracted from PDF' },
        { status: 400 }
      );
    }

    const resultsToInsert: any[] = [];
    const drawDateTime = new Date(drawDate);

    if (parsedResults.firstPrize) {
      resultsToInsert.push({
        draw,
        draw_date: drawDateTime.toISOString(),
        number: parsedResults.firstPrize,
        prize_type: 'first',
        amount: 7500000,
      });
    }

    parsedResults.secondPrizes.forEach((number) => {
      resultsToInsert.push({
        draw,
        draw_date: drawDateTime.toISOString(),
        number,
        prize_type: 'second',
        amount: 750000,
      });
    });

    parsedResults.thirdPrizes.forEach((number) => {
      resultsToInsert.push({
        draw,
        draw_date: drawDateTime.toISOString(),
        number,
        prize_type: 'third',
        amount: 40000,
      });
    });

    const insertedResults = await addResults(resultsToInsert);

    const bonds = await getBonds();
    const matches = insertedResults.filter((result) =>
      bonds.some((bond) => bond.number === result.number)
    );

    const totalWins = matches.reduce((sum, match) => sum + match.amount, 0);
    await upsertHistory(draw, drawDateTime, matches.length, totalWins);

    return NextResponse.json(
      {
        success: true,
        message: `Processed ${insertedResults.length} prize numbers. Found ${matches.length} matching bonds.`,
        data: {
          resultsCount: insertedResults.length,
          matchCount: matches.length,
          totalWins,
          parsed: {
            firstPrize: parsedResults.firstPrize,
            secondPrizes: parsedResults.secondPrizes.length,
            thirdPrizes: parsedResults.thirdPrizes.length,
          },
        },
      },
      { status: 201 }
    );
  } catch (error: any) {
    console.error('Error processing PDF:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to process PDF. Please ensure it contains valid 6-digit numbers.' },
      { status: 500 }
    );
  }
}
