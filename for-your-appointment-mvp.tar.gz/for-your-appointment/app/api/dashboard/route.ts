import { NextRequest, NextResponse } from 'next/server';
import { getBonds, getAllResults, getHistory } from '@/lib/supabase';
import { calculateStats } from '@/lib/match-logic';

export async function GET(request: NextRequest) {
  try {
    const bonds = await getBonds();
    const allResults = await getAllResults();
    const history = await getHistory();

    const totalInvestment = bonds.reduce((sum, bond) => sum + (bond.denomination || 0), 0);
    const totalWins = allResults.reduce((sum, result) => sum + result.amount, 0);
    const winningBonds = new Set(allResults.map((r) => r.number));
    const winCount = winningBonds.size;

    const roi = totalInvestment > 0 ? ((totalWins / totalInvestment) * 100).toFixed(2) : '0.00';

    return NextResponse.json(
      {
        success: true,
        stats: {
          totalBonds: bonds.length,
          totalInvestment,
          totalWins,
          roi: parseFloat(roi),
          winCount,
        },
        history: history.map((h) => ({
          draw: h.draw,
          drawDate: h.draw_date,
          totalWins: h.total_wins,
          totalAmount: h.total_amount,
        })),
        latestResults: allResults.slice(0, 10),
      },
      { status: 200 }
    );
  } catch (error: any) {
    console.error('Error fetching dashboard data:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to fetch dashboard data' },
      { status: 500 }
    );
  }
}
