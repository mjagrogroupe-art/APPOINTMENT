# Quick Start Guide

This guide provides a condensed walkthrough for getting the Prize Bond Intelligence System up and running in minutes.

## Prerequisites

Before beginning, ensure you have Node.js 18 or later installed on your computer. You can verify this by opening a terminal and running `node --version`. If you do not have Node.js installed, download it from https://nodejs.org/.

You will also need a Supabase account, which is free to create at https://supabase.com/. The free tier is more than sufficient for personal use.

## Setup in 5 Minutes

### 1. Clone and Install (1 minute)

Open your terminal and run the following commands to clone the repository and install dependencies.

```bash
git clone <your-repository-url>
cd for-your-appointment
npm install
```

This downloads the project and installs all required packages. The process takes approximately one minute depending on your internet connection.

### 2. Create Supabase Project (2 minutes)

Visit https://app.supabase.com/ and create a new project. Enter a project name, password, and select a region closest to your location. The project initialization takes approximately one minute. Once complete, you will see your project dashboard.

### 3. Initialize Database (1 minute)

In your Supabase dashboard, open the SQL Editor from the left sidebar. Copy the entire contents of the `scripts/init-db.sql` file from the project directory and paste it into the SQL editor. Click the Execute button to run the initialization script. You should see "Success" messages indicating that all tables have been created.

### 4. Configure Environment (1 minute)

Copy the `.env.example` file to `.env.local` using the terminal command `cp .env.example .env.local`. Edit the `.env.local` file and replace the placeholder values with your actual Supabase credentials. You can find these credentials by clicking Settings in your Supabase dashboard and navigating to the API section.

## Running the Application

Start the development server by running `npm run dev` in your terminal. The application will start on http://localhost:3000. Open this URL in your web browser and begin using the application immediately.

## First Steps

Once the application is running, navigate to the Add Bond page and enter your first prize bond. Use any 6-digit number for testing purposes. Then, download a sample lottery draw result PDF from an official source and upload it on the Upload Result page to test the PDF processing functionality.

Your dashboard will automatically populate with statistics once you have added bonds and uploaded a draw result.

## Troubleshooting Quick Fixes

If you encounter a "Missing Supabase environment variables" error, verify that your `.env.local` file exists in the project root directory and contains the correct values from your Supabase project.

If the application shows a blank dashboard, this is normal when no bonds have been added yet. Navigate to the Add Bond page to add your first bond.

If PDF processing fails, ensure your test PDF contains properly formatted 6-digit numbers in the expected format. Official lottery result PDFs typically work correctly without modification.

## Next Steps

For more detailed information, refer to the comprehensive README.md file included in the project. For deployment instructions, see DEPLOYMENT.md.

## Getting Help

If you encounter issues that are not covered in the troubleshooting section, check the application logs in your browser's developer console (press F12 to open). The error messages displayed there typically indicate the specific issue preventing normal operation.
