# For Your Appointment - Prize Bond Intelligence System

A lightweight, production-ready MVP web application for tracking prize bonds, uploading draw results, and analyzing investment returns with automatic number extraction and matching.

## Overview

For Your Appointment is a single-user intelligence system designed to help prize bond investors manage their portfolio efficiently. The application automates the process of tracking bonds, extracting winning numbers from PDF results, and calculating detailed ROI metrics.

### Key Features

**Bond Management**: Add, store, and organize your prize bond inventory with serial numbers and denominations. Each bond is validated and stored in a secure PostgreSQL database.

**PDF Processing**: Upload lottery draw result PDFs and automatically extract all 6-digit numbers using text parsing with OCR fallback. The system intelligently classifies numbers as first, second, or third prizes.

**Automatic Matching**: Compare extracted draw numbers against your bond inventory in real-time. The system instantly identifies which bonds have won and retrieves corresponding prize amounts.

**Dashboard Analytics**: View comprehensive statistics including total investment, total winnings, number of winning bonds, and ROI percentage. Historical data shows performance across draws.

**Responsive Design**: Clean, dark-themed interface optimized for desktop and mobile devices with smooth animations and intuitive navigation.

## Technology Stack

- **Framework**: Next.js 14 with App Router and TypeScript
- **Frontend**: React 18 with Tailwind CSS for styling
- **Backend**: Node.js API routes for server-side processing
- **Database**: Supabase (PostgreSQL) for data persistence
- **PDF Processing**: pdf-parse for text extraction with tesseract.js for OCR fallback
- **HTTP Client**: Axios for API calls

## Prerequisites

Before setting up the application, ensure you have the following installed on your system:

- Node.js 18 or later (download from https://nodejs.org/)
- npm or yarn package manager (included with Node.js)
- A Supabase account (free tier available at https://supabase.com/)
- Git for version control

## Quick Start

### Step 1: Clone the Repository

```bash
git clone <repository-url>
cd for-your-appointment
```

### Step 2: Install Dependencies

```bash
npm install
```

This command installs all required packages including Next.js, React, Supabase client, and PDF processing libraries.

### Step 3: Set Up Supabase

Create a new Supabase project:

Visit https://app.supabase.com/ and create a new project. Wait for the project to initialize (approximately 2 minutes). Once ready, retrieve your project credentials from the Settings menu under API keys.

Initialize the database tables by running the SQL script:

Open the SQL Editor in your Supabase dashboard. Copy the entire contents of `scripts/init-db.sql`. Paste the SQL into the editor and execute it to create all required tables and indexes.

### Step 4: Configure Environment Variables

Create a `.env.local` file in the project root directory:

```bash
cp .env.example .env.local
```

Edit `.env.local` and add your Supabase credentials:

```
NEXT_PUBLIC_SUPABASE_URL=https://your-project-id.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key-from-supabase
```

Replace the placeholder values with your actual Supabase project URL and anonymous key, which are available in your Supabase project settings under the API section.

### Step 5: Run the Development Server

```bash
npm run dev
```

The application will start on http://localhost:3000. Open this URL in your web browser. You should see the dashboard page with empty statistics.

### Step 6: Start Using the Application

Navigate to the "Add Bond" page and enter your first prize bond. Then upload a draw result PDF to test the matching functionality. The dashboard will automatically update with your statistics.

## Project Structure

The application follows Next.js best practices with the following directory organization:

```
for-your-appointment/
├── app/
│   ├── api/
│   │   ├── add-bond/route.ts          # Create new bond
│   │   ├── bonds/[id]/route.ts        # Delete bond
│   │   ├── bonds/route.ts             # Retrieve all bonds
│   │   ├── check-results/route.ts     # Check for wins
│   │   ├── dashboard/route.ts         # Dashboard statistics
│   │   └── upload-pdf/route.ts        # Process PDF results
│   ├── add-bond/page.tsx              # Bond management page
│   ├── dashboard/page.tsx             # Main dashboard page
│   ├── upload-result/page.tsx         # PDF upload page
│   ├── globals.css                    # Global styles
│   └── layout.tsx                     # Root layout with navigation
├── components/
│   ├── BondForm.tsx                   # Bond entry form
│   ├── BondsList.tsx                  # Bond list display
│   ├── Layout.tsx                     # Navigation and layout
│   ├── PDFUpload.tsx                  # PDF upload component
│   ├── ResultsTable.tsx               # Results display table
│   └── StatsCards.tsx                 # Dashboard stat cards
├── lib/
│   ├── match-logic.ts                 # Bond matching algorithm
│   ├── pdf-parser.ts                  # PDF text extraction
│   └── supabase.ts                    # Database operations
├── scripts/
│   └── init-db.sql                    # Database initialization
├── .env.example                       # Environment template
├── next.config.js                     # Next.js configuration
├── package.json                       # Dependencies
├── postcss.config.js                  # PostCSS configuration
├── tailwind.config.js                 # Tailwind configuration
└── tsconfig.json                      # TypeScript configuration
```

## API Reference

### Bond Management

**POST /api/add-bond**: Create a new prize bond in the inventory. Request body must include serial (string), number (6-digit string), and denomination (integer). Returns the created bond object with unique ID.

**GET /api/bonds**: Retrieve all bonds in the inventory. Returns an array of bond objects sorted by creation date in descending order.

**DELETE /api/bonds/[id]**: Remove a bond from the inventory. Requires the bond UUID as a path parameter. Returns a success message on completion.

### PDF Processing

**POST /api/upload-pdf**: Upload and process a draw result PDF. Accepts FormData with file (PDF), draw (string), and drawDate (ISO date string). Automatically extracts numbers and matches against bonds. Returns count of extracted numbers, matches found, and total winnings.

**GET /api/check-results**: Retrieve all matched winning bonds across all draws. Returns an array of matches with bond numbers, prize types, and amounts.

### Dashboard and Analytics

**GET /api/dashboard**: Retrieve complete dashboard data including statistics (total bonds, investment, wins, ROI), historical draw data, and recent results. Used by the main dashboard page.

## PDF Processing Logic

The application uses an intelligent two-stage approach for extracting lottery numbers from PDFs:

**Stage 1: Text Extraction**: The system first attempts to extract text directly from the PDF using pdf-parse. This method is fast and works for PDFs with embedded text.

**Stage 2: OCR Fallback**: If text extraction returns no valid 6-digit numbers, the system automatically falls back to optical character recognition using tesseract.js. This handles scanned PDFs or images.

**Number Classification**: After extraction, the system classifies extracted 6-digit numbers as follows. The first number is classified as the 1st Prize winner. The next three numbers are classified as 2nd Prize winners. All remaining numbers are classified as 3rd Prize winners.

**Prize Amounts**: The system uses standard prize amounts. 1st Prize awards 7,500,000 PKR. 2nd Prize awards 750,000 PKR per winner. 3rd Prize awards 40,000 PKR per winner. These values can be customized by modifying the `app/api/upload-pdf/route.ts` file.

## Database Schema

The application uses three main tables for data organization:

**bonds**: Stores individual prize bonds with columns for UUID (id), serial number, 6-digit number, denomination amount, purchase date, and creation timestamp. Includes a unique index on the number field to prevent duplicates.

**results**: Stores lottery draw results with columns for UUID (id), draw name, draw date, winning number, prize type (first/second/third), prize amount, and creation timestamp. Includes indexes on number and draw fields for fast lookups.

**history**: Aggregates winning statistics by draw with columns for UUID (id), draw name, draw date, total wins count, total prize amount, and creation timestamp. Includes an index on draw field.

All timestamps are stored in UTC format. The database uses UUID primary keys for all tables to ensure uniqueness across systems.

## Deployment Guide

### Deploy to Vercel (Recommended)

Vercel provides the simplest deployment path for Next.js applications.

Create a new project on Vercel: Visit https://vercel.com/new and connect your GitHub repository.

Configure environment variables in Vercel project settings: Add your NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY to the environment variables section.

Deploy your application: Vercel will automatically deploy your application and provide a live URL.

### Deploy to Other Platforms

For self-hosted deployments on platforms like AWS, DigitalOcean, or Heroku, follow these steps:

Build the production bundle: Run `npm run build` to create an optimized production build.

Start the server: Run `npm start` to start the production server on port 3000.

Set environment variables: Configure NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY as system environment variables on your hosting platform.

Ensure your platform supports Node.js 18 or later and has a minimum of 512MB RAM.

## Configuration and Customization

### Changing Prize Amounts

To modify standard prize amounts, edit the `app/api/upload-pdf/route.ts` file. Look for the section where prize amounts are defined and update the values to match your lottery scheme.

### Customizing the UI Theme

The application uses Tailwind CSS with a dark theme. You can customize colors by editing `tailwind.config.js`. All color tokens are defined in the theme extension section for easy modification.

### Modifying PDF Extraction Logic

For advanced PDF processing, edit `lib/pdf-parser.ts`. The module exports `parsePDFText` for text-based extraction and `parseWithOCR` for image-based extraction. You can adjust extraction parameters or add custom preprocessing logic.

## Troubleshooting

**Blank dashboard after login**: This is normal. You need to add bonds first via the "Add Bond" page before statistics will appear.

**PDF processing fails with "No 6-digit numbers found"**: Ensure the PDF contains valid 6-digit numbers in the expected format. Try downloading the official draw result PDF directly from the issuing authority.

**"Bond number already exists" error**: Each bond number can only be added once to prevent duplicates. You may have added this number previously.

**Supabase connection errors**: Verify that your environment variables are correctly set in `.env.local`. Check that your Supabase project is active and has not exceeded its rate limits.

**OCR processing is very slow**: This is expected for scanned PDFs as OCR is computationally intensive. The process typically completes within 30 seconds. Consider using PDFs with embedded text for faster processing.

## Performance Considerations

The application is optimized for single-user operation with the following performance characteristics:

Database queries are indexed on frequently searched fields (number, draw, creation date) for sub-millisecond response times. The PDF processing pipeline handles files up to 10MB efficiently, with OCR operations completing within 30 seconds on modern hardware.

For optimal performance, keep your bond inventory under 10,000 entries and your results database under 100,000 entries. Regular backups of your Supabase database are recommended using the Supabase backup feature.

## Security Notes

The application uses Supabase's Row Level Security (RLS) is disabled for simplicity in this MVP. For production deployments, enable RLS policies to restrict database access. All API routes validate input to prevent injection attacks.

Environment variables prefixed with `NEXT_PUBLIC_` are exposed to the browser. Do not store secrets in these variables. The Supabase anonymous key provided is designed for client-side use and has limited permissions by default.

## Support and Contributing

For issues, feature requests, or questions, please create an issue on the GitHub repository. This is an open-source project and contributions are welcome through pull requests.

## License

This project is provided as-is for personal use and modification.

## FAQ

**Can multiple users access the same instance?** Currently, the application is designed for single-user operation. To support multiple users, the database schema would need to be extended with user IDs and Row Level Security policies would need to be enabled.

**How often should I backup my data?** Supabase provides automatic daily backups on paid plans. For the free tier, manual backups are recommended before major changes.

**What is the maximum number of bonds I can track?** The application can handle thousands of bonds efficiently. Performance depends on your Supabase plan limits, but typically 10,000+ bonds are easily supported.

**Can I export my data?** Yes, you can export data directly from Supabase using their export tools or by querying the database and exporting to CSV format.

**Is there a mobile app?** The web application is fully responsive and works on mobile browsers. A native mobile app is not currently available.
