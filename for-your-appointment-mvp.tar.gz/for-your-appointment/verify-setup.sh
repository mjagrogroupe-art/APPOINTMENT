#!/bin/bash

echo "================================================"
echo "For Your Appointment - Setup Verification"
echo "================================================"
echo ""

# Check Node.js
echo "✓ Checking Node.js installation..."
if command -v node &> /dev/null; then
    NODE_VERSION=$(node --version)
    echo "  Node.js version: $NODE_VERSION"
else
    echo "  ✗ Node.js not found. Please install Node.js 18 or later."
    exit 1
fi

# Check npm
echo "✓ Checking npm installation..."
if command -v npm &> /dev/null; then
    NPM_VERSION=$(npm --version)
    echo "  npm version: $NPM_VERSION"
else
    echo "  ✗ npm not found. Please install npm."
    exit 1
fi

# Check .env.local
echo "✓ Checking environment configuration..."
if [ -f .env.local ]; then
    echo "  .env.local file found"
    if grep -q "NEXT_PUBLIC_SUPABASE_URL" .env.local; then
        echo "  ✓ NEXT_PUBLIC_SUPABASE_URL configured"
    else
        echo "  ✗ NEXT_PUBLIC_SUPABASE_URL not found in .env.local"
    fi
    if grep -q "NEXT_PUBLIC_SUPABASE_ANON_KEY" .env.local; then
        echo "  ✓ NEXT_PUBLIC_SUPABASE_ANON_KEY configured"
    else
        echo "  ✗ NEXT_PUBLIC_SUPABASE_ANON_KEY not found in .env.local"
    fi
else
    echo "  ✗ .env.local not found. Please create .env.local from .env.example"
    exit 1
fi

# Check dependencies
echo "✓ Checking dependencies..."
if [ -d node_modules ]; then
    echo "  node_modules directory found"
else
    echo "  ✗ node_modules not found. Run 'npm install' first."
    exit 1
fi

# Check required files
echo "✓ Checking project structure..."
REQUIRED_FILES=(
    "package.json"
    "tailwind.config.js"
    "next.config.js"
    "tsconfig.json"
    "scripts/init-db.sql"
    "app/layout.tsx"
    "app/dashboard/page.tsx"
    "lib/supabase.ts"
)

for file in "${REQUIRED_FILES[@]}"; do
    if [ -f "$file" ]; then
        echo "  ✓ $file"
    else
        echo "  ✗ $file not found"
    fi
done

echo ""
echo "================================================"
echo "Setup Verification Complete"
echo "================================================"
echo ""
echo "Next steps:"
echo "1. Run 'npm run dev' to start the development server"
echo "2. Open http://localhost:3000 in your browser"
echo "3. Add your first prize bond via the 'Add Bond' page"
echo "4. Upload a draw result PDF via the 'Upload Result' page"
echo "5. View your dashboard with statistics"
echo ""
echo "For more information, see:"
echo "  - QUICKSTART.md for rapid setup"
echo "  - README.md for comprehensive documentation"
echo "  - DEPLOYMENT.md for production deployment"
echo ""
