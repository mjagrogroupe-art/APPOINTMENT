import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';

if (!supabaseUrl || !supabaseKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseKey);

// Bond operations
export const addBond = async (serial: string, number: string, denomination: number) => {
  const { data, error } = await supabase
    .from('bonds')
    .insert([{ serial, number, denomination }])
    .select();
  if (error) throw error;
  return data?.[0];
};

export const getBonds = async () => {
  const { data, error } = await supabase
    .from('bonds')
    .select('*')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data || [];
};

export const deleteBond = async (id: string) => {
  const { error } = await supabase.from('bonds').delete().eq('id', id);
  if (error) throw error;
};

// Result operations
export const addResults = async (results: any[]) => {
  const { data, error } = await supabase
    .from('results')
    .insert(results)
    .select();
  if (error) throw error;
  return data || [];
};

export const getResultsByDraw = async (draw: string) => {
  const { data, error } = await supabase
    .from('results')
    .select('*')
    .eq('draw', draw)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data || [];
};

export const getAllResults = async () => {
  const { data, error } = await supabase
    .from('results')
    .select('*')
    .order('draw_date', { ascending: false });
  if (error) throw error;
  return data || [];
};

// History operations
export const upsertHistory = async (draw: string, drawDate: Date, totalWins: number, totalAmount: number) => {
  const { data, error } = await supabase
    .from('history')
    .upsert([{ draw, draw_date: drawDate.toISOString(), total_wins: totalWins, total_amount: totalAmount }], {
      onConflict: 'draw',
    })
    .select();
  if (error) throw error;
  return data?.[0];
};

export const getHistory = async () => {
  const { data, error } = await supabase
    .from('history')
    .select('*')
    .order('draw_date', { ascending: false });
  if (error) throw error;
  return data || [];
};
