import pdfParse from 'pdf-parse';
import Tesseract from 'tesseract.js';

interface ParsedResult {
  firstPrize: string | null;
  secondPrizes: string[];
  thirdPrizes: string[];
}

const extractNumbersFromText = (text: string): string[] => {
  const numbers = text.match(/\b\d{6}\b/g) || [];
  return [...new Set(numbers)]; // Remove duplicates
};

export const parsePDFText = async (buffer: Buffer): Promise<ParsedResult> => {
  try {
    const pdf = await pdfParse(buffer);
    const text = pdf.text;

    if (!text || text.trim().length === 0) {
      throw new Error('No text extracted from PDF');
    }

    const numbers = extractNumbersFromText(text);

    if (numbers.length === 0) {
      throw new Error('No 6-digit numbers found in PDF text');
    }

    return {
      firstPrize: numbers[0] || null,
      secondPrizes: numbers.slice(1, 4),
      thirdPrizes: numbers.slice(4),
    };
  } catch (error) {
    console.log('Text extraction failed, attempting OCR...');
    throw error;
  }
};

export const parseWithOCR = async (buffer: Buffer): Promise<ParsedResult> => {
  try {
    const { data: { text } } = await Tesseract.recognize(buffer, 'eng', {
      logger: (m) => console.log('Tesseract progress:', m.progress),
    });

    const numbers = extractNumbersFromText(text);

    if (numbers.length === 0) {
      throw new Error('No 6-digit numbers found via OCR');
    }

    return {
      firstPrize: numbers[0] || null,
      secondPrizes: numbers.slice(1, 4),
      thirdPrizes: numbers.slice(4),
    };
  } catch (error) {
    console.error('OCR parsing failed:', error);
    throw error;
  }
};

export const parseDrawResultPDF = async (buffer: Buffer): Promise<ParsedResult> => {
  try {
    return await parsePDFText(buffer);
  } catch {
    return await parseWithOCR(buffer);
  }
};
