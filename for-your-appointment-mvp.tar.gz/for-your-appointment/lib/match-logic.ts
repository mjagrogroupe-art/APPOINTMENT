interface BondMatch {
  bondId: string;
  bondNumber: string;
  prizeType: string;
  amount: number;
}

export const matchBondsWithResults = (bonds: any[], results: any[]): BondMatch[] => {
  const matches: BondMatch[] = [];
  const bondMap = new Map(bonds.map(b => [b.number, b.id]));

  results.forEach((result) => {
    if (bondMap.has(result.number)) {
      matches.push({
        bondId: bondMap.get(result.number)!,
        bondNumber: result.number,
        prizeType: result.prize_type,
        amount: result.amount,
      });
    }
  });

  return matches;
};

export const calculateStats = (bonds: any[], matches: BondMatch[]) => {
  const totalInvestment = bonds.reduce((sum, bond) => sum + (bond.denomination || 0), 0);
  const totalWins = matches.reduce((sum, match) => sum + match.amount, 0);
  const roi = totalInvestment > 0 ? ((totalWins / totalInvestment) * 100).toFixed(2) : '0.00';

  return {
    totalBonds: bonds.length,
    totalInvestment,
    totalWins,
    roi: parseFloat(roi),
    winCount: matches.length,
  };
};
