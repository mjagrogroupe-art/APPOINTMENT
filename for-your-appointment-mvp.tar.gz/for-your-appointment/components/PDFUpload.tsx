'use client';

import { ChangeEvent, FormEvent, useState } from 'react';

interface PDFUploadProps {
  onUpload: (file: File, draw: string, drawDate: string) => Promise<void>;
  isLoading: boolean;
}

export function PDFUpload({ onUpload, isLoading }: PDFUploadProps) {
  const [file, setFile] = useState<File | null>(null);
  const [draw, setDraw] = useState('');
  const [drawDate, setDrawDate] = useState('');
  const [error, setError] = useState('');
  const [fileName, setFileName] = useState('');

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      if (selectedFile.type !== 'application/pdf') {
        setError('Only PDF files are accepted');
        setFile(null);
        setFileName('');
        return;
      }
      if (selectedFile.size > 10 * 1024 * 1024) {
        setError('File size must be less than 10MB');
        setFile(null);
        setFileName('');
        return;
      }
      setFile(selectedFile);
      setFileName(selectedFile.name);
      setError('');
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError('');

    if (!file) {
      setError('Please select a PDF file');
      return;
    }

    if (!draw.trim()) {
      setError('Draw name is required (e.g., "Draw 2024-01")');
      return;
    }

    if (!drawDate) {
      setError('Draw date is required');
      return;
    }

    try {
      await onUpload(file, draw.trim(), drawDate);
      setFile(null);
      setFileName('');
      setDraw('');
      setDrawDate('');
    } catch (err: any) {
      setError(err.message || 'Failed to process PDF');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="card max-w-md animate-fade-in">
      <h3 className="subsection-title">Upload Draw Result PDF</h3>

      {error && (
        <div className="mb-4 p-3 bg-red-500/10 border border-red-500/30 text-red-300 rounded-lg text-sm">
          {error}
        </div>
      )}

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-2">Draw Name</label>
          <input
            type="text"
            value={draw}
            onChange={(e) => setDraw(e.target.value)}
            placeholder="e.g., Draw 2024-01"
            className="input-field"
            disabled={isLoading}
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Draw Date</label>
          <input
            type="date"
            value={drawDate}
            onChange={(e) => setDrawDate(e.target.value)}
            className="input-field"
            disabled={isLoading}
          />
        </div>

        <div className="border-2 border-dashed border-dark-border rounded-lg p-6 hover:border-primary-600 transition-colors cursor-pointer text-center">
          <input
            type="file"
            accept=".pdf"
            onChange={handleFileChange}
            className="hidden"
            id="pdf-upload"
            disabled={isLoading}
          />
          <label htmlFor="pdf-upload" className="cursor-pointer">
            <div className="text-2xl mb-2">📄</div>
            <p className="text-sm font-medium">
              {fileName || 'Click to select PDF or drag and drop'}
            </p>
            <p className="text-xs text-text-muted mt-1">Max 10MB</p>
          </label>
        </div>

        <button type="submit" className="btn-primary w-full" disabled={isLoading || !file}>
          {isLoading ? 'Processing...' : 'Upload & Process'}
        </button>
      </div>
    </form>
  );
}
