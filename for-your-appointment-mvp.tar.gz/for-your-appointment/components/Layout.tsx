'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { ReactNode } from 'react';

export default function Layout({ children }: { children: ReactNode }) {
  const pathname = usePathname();

  const isActive = (path: string) => pathname === path;

  return (
    <div className="min-h-screen bg-dark-bg text-text-light">
      <nav className="border-b border-dark-border bg-dark-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/dashboard" className="flex items-center gap-2 group">
              <div className="w-8 h-8 bg-gradient-to-br from-primary-500 to-accent-500 rounded-lg flex items-center justify-center font-bold text-sm group-hover:shadow-lg transition-shadow">
                FY
              </div>
              <span className="font-semibold text-lg hidden sm:inline">For Your Appointment</span>
            </Link>

            <div className="flex gap-1 sm:gap-2">
              {[
                { href: '/dashboard', label: 'Dashboard', icon: '📊' },
                { href: '/add-bond', label: 'Add Bond', icon: '➕' },
                { href: '/upload-result', label: 'Upload Result', icon: '📄' },
              ].map(({ href, label, icon }) => (
                <Link
                  key={href}
                  href={href}
                  className={`px-3 sm:px-4 py-2 rounded-lg transition-all duration-200 font-medium text-sm sm:text-base ${
                    isActive(href)
                      ? 'bg-primary-600 text-white shadow-lg'
                      : 'text-text-muted hover:text-text-light hover:bg-dark-bg'
                  }`}
                >
                  <span className="sm:hidden">{icon}</span>
                  <span className="hidden sm:inline">{label}</span>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {children}
      </main>

      <footer className="border-t border-dark-border bg-dark-card/30 mt-16 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-text-muted text-sm">
          <p>For Your Appointment © 2024 · Prize Bond Intelligence System</p>
        </div>
      </footer>
    </div>
  );
}
