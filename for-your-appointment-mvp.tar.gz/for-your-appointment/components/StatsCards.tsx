'use client';

interface StatsCardsProps {
  totalBonds: number;
  totalInvestment: number;
  totalWins: number;
  roi: number;
  winCount: number;
}

export function StatsCards({
  totalBonds,
  totalInvestment,
  totalWins,
  roi,
  winCount,
}: StatsCardsProps) {
  const stats = [
    {
      label: 'Total Bonds',
      value: totalBonds,
      unit: '',
      color: 'from-blue-500 to-blue-600',
      icon: '📦',
    },
    {
      label: 'Total Investment',
      value: totalInvestment.toLocaleString(),
      unit: 'PKR',
      color: 'from-purple-500 to-purple-600',
      icon: '💰',
    },
    {
      label: 'Total Wins',
      value: totalWins.toLocaleString(),
      unit: 'PKR',
      color: 'from-green-500 to-green-600',
      icon: '🎁',
    },
    {
      label: 'ROI',
      value: roi.toFixed(2),
      unit: '%',
      color: 'from-orange-500 to-orange-600',
      icon: '📈',
    },
    {
      label: 'Winning Bonds',
      value: winCount,
      unit: '',
      color: 'from-pink-500 to-pink-600',
      icon: '⭐',
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
      {stats.map((stat, idx) => (
        <div
          key={idx}
          className="stat-card animate-fade-in"
          style={{ animationDelay: `${idx * 50}ms` }}
        >
          <div className="flex items-start justify-between mb-3">
            <div className="text-3xl">{stat.icon}</div>
            <div className={`text-2xl font-bold bg-gradient-to-r ${stat.color} bg-clip-text text-transparent`}>
              {stat.value}{stat.unit && <span className="text-xs ml-1">{stat.unit}</span>}
            </div>
          </div>
          <p className="text-text-muted text-sm font-medium">{stat.label}</p>
        </div>
      ))}
    </div>
  );
}
