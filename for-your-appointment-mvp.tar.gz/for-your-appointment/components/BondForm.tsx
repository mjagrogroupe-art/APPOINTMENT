'use client';

import { FormEvent, useState } from 'react';

interface BondFormProps {
  onSubmit: (serial: string, number: string, denomination: number) => Promise<void>;
  isLoading: boolean;
}

export function BondForm({ onSubmit, isLoading }: BondFormProps) {
  const [serial, setSerial] = useState('');
  const [number, setNumber] = useState('');
  const [denomination, setDenomination] = useState('100');
  const [error, setError] = useState('');

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError('');

    if (!serial.trim() || !number.trim()) {
      setError('Serial and number are required');
      return;
    }

    if (number.length !== 6 || !/^\d+$/.test(number)) {
      setError('Bond number must be exactly 6 digits');
      return;
    }

    try {
      await onSubmit(serial.trim(), number.trim(), parseInt(denomination));
      setSerial('');
      setNumber('');
      setDenomination('100');
    } catch (err: any) {
      setError(err.message || 'Failed to add bond');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="card max-w-md animate-fade-in">
      <h3 className="subsection-title">Add New Prize Bond</h3>

      {error && (
        <div className="mb-4 p-3 bg-red-500/10 border border-red-500/30 text-red-300 rounded-lg text-sm">
          {error}
        </div>
      )}

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-2">Serial Number</label>
          <input
            type="text"
            value={serial}
            onChange={(e) => setSerial(e.target.value)}
            placeholder="e.g., ABC123"
            className="input-field"
            disabled={isLoading}
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Bond Number (6 digits)</label>
          <input
            type="text"
            value={number}
            onChange={(e) => setNumber(e.target.value.replace(/\D/g, '').slice(0, 6))}
            placeholder="e.g., 123456"
            className="input-field"
            maxLength={6}
            disabled={isLoading}
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Denomination (PKR)</label>
          <select
            value={denomination}
            onChange={(e) => setDenomination(e.target.value)}
            className="input-field cursor-pointer"
            disabled={isLoading}
          >
            <option value="100">100</option>
            <option value="500">500</option>
            <option value="1500">1,500</option>
            <option value="5000">5,000</option>
            <option value="10000">10,000</option>
            <option value="15000">15,000</option>
            <option value="25000">25,000</option>
          </select>
        </div>

        <button type="submit" className="btn-primary w-full" disabled={isLoading}>
          {isLoading ? 'Adding...' : 'Add Bond'}
        </button>
      </div>
    </form>
  );
}
