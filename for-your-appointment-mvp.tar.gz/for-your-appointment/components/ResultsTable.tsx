'use client';

interface Result {
  id: string;
  bondNumber: string;
  draw: string;
  prizeType: string;
  amount: number;
  drawDate?: string;
}

interface ResultsTableProps {
  results: Result[];
  isLoading?: boolean;
}

const prizeLabels: Record<string, string> = {
  first: '🏆 1st Prize',
  second: '🥈 2nd Prize',
  third: '🥉 3rd Prize',
};

export function ResultsTable({ results, isLoading }: ResultsTableProps) {
  if (isLoading) {
    return (
      <div className="card text-center py-12">
        <p className="text-text-muted">Loading results...</p>
      </div>
    );
  }

  if (results.length === 0) {
    return (
      <div className="card text-center py-12">
        <p className="text-2xl mb-2">🔍</p>
        <p className="text-text-muted">No winning bonds found yet</p>
        <p className="text-xs text-text-muted mt-1">Upload draw results to check for matches</p>
      </div>
    );
  }

  return (
    <div className="card animate-fade-in">
      <h3 className="subsection-title">Your Winning Bonds</h3>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-dark-border">
              <th className="text-left py-3 px-4 font-semibold text-text-muted">Bond #</th>
              <th className="text-left py-3 px-4 font-semibold text-text-muted">Draw</th>
              <th className="text-left py-3 px-4 font-semibold text-text-muted">Prize</th>
              <th className="text-right py-3 px-4 font-semibold text-text-muted">Amount (PKR)</th>
            </tr>
          </thead>
          <tbody>
            {results.map((result, idx) => (
              <tr key={result.id} className="border-b border-dark-border/50 hover:bg-dark-bg/50 transition-colors">
                <td className="py-3 px-4 font-mono font-semibold text-accent-400">{result.bondNumber}</td>
                <td className="py-3 px-4 text-text-light">{result.draw}</td>
                <td className="py-3 px-4">
                  <span className="inline-block px-3 py-1 bg-accent-500/10 border border-accent-500/30 text-accent-400 rounded-full text-xs font-medium">
                    {prizeLabels[result.prizeType] || result.prizeType}
                  </span>
                </td>
                <td className="py-3 px-4 text-right font-bold text-accent-500">
                  {result.amount.toLocaleString()}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-6 pt-6 border-t border-dark-border">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-text-muted text-sm">Total Wins</p>
            <p className="text-2xl font-bold text-accent-500">
              {results.reduce((sum, r) => sum + r.amount, 0).toLocaleString()} PKR
            </p>
          </div>
          <div>
            <p className="text-text-muted text-sm">Winning Bonds</p>
            <p className="text-2xl font-bold text-primary-500">{results.length}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
