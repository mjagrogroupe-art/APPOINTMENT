'use client';

interface Bond {
  id: string;
  serial: string;
  number: string;
  denomination: number;
}

interface BondsListProps {
  bonds: Bond[];
  onDelete: (id: string) => Promise<void>;
  isLoading?: boolean;
}

export function BondsList({ bonds, onDelete, isLoading }: BondsListProps) {
  const handleDelete = async (id: string) => {
    if (confirm('Are you sure you want to delete this bond?')) {
      try {
        await onDelete(id);
      } catch (err: any) {
        alert(err.message || 'Failed to delete bond');
      }
    }
  };

  if (bonds.length === 0) {
    return (
      <div className="card text-center py-12">
        <p className="text-2xl mb-2">🎟️</p>
        <p className="text-text-muted">No bonds added yet</p>
        <p className="text-xs text-text-muted mt-1">Add your first prize bond to get started</p>
      </div>
    );
  }

  return (
    <div className="card animate-fade-in">
      <h3 className="subsection-title">Your Prize Bonds ({bonds.length})</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {bonds.map((bond) => (
          <div
            key={bond.id}
            className="flex items-center justify-between p-4 bg-dark-bg rounded-lg border border-dark-border hover:border-primary-600/50 transition-colors"
          >
            <div>
              <p className="font-mono font-semibold text-primary-400">{bond.number}</p>
              <p className="text-xs text-text-muted">{bond.serial} · {bond.denomination} PKR</p>
            </div>
            <button
              onClick={() => handleDelete(bond.id)}
              disabled={isLoading}
              className="p-2 text-text-muted hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors disabled:opacity-50"
              title="Delete bond"
            >
              ✕
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
