-- Bonds table: Store all user's prize bonds
CREATE TABLE bonds (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  serial TEXT NOT NULL,
  number TEXT NOT NULL UNIQUE,
  denomination INTEGER NOT NULL,
  purchase_date TIMESTAMP DEFAULT now(),
  created_at TIMESTAMP DEFAULT now()
);

-- Results table: Store all lottery draw results
CREATE TABLE results (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  draw TEXT NOT NULL,
  draw_date TIMESTAMP NOT NULL,
  number TEXT NOT NULL,
  prize_type TEXT NOT NULL, -- 'first', 'second', 'third'
  amount INTEGER NOT NULL,
  created_at TIMESTAMP DEFAULT now()
);

-- History table: Store aggregated win history
CREATE TABLE history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  draw TEXT NOT NULL,
  draw_date TIMESTAMP NOT NULL,
  total_wins INTEGER DEFAULT 0,
  total_amount INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT now()
);

-- Create indexes for fast queries
CREATE INDEX idx_bonds_number ON bonds(number);
CREATE INDEX idx_results_number ON results(number);
CREATE INDEX idx_results_draw ON results(draw);
CREATE INDEX idx_history_draw ON history(draw);
