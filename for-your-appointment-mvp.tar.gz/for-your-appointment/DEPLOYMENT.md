# Deployment Checklist & Operational Guide

## Pre-Deployment Verification

Before deploying the Prize Bond Intelligence System to production, ensure you have completed all of the following items. These steps are critical for ensuring system reliability and data security.

### Development Environment Confirmation

Verify that you have successfully run the development server locally and confirmed that all core features are functioning as expected. This includes successfully adding at least one bond, uploading a test PDF result, and observing the dashboard update with matching statistics. Test all three primary pages (Dashboard, Add Bond, Upload Result) and verify navigation between them works correctly. Ensure that the application displays no console errors when performing these operations.

### Supabase Configuration Verification

Confirm that your Supabase project is fully initialized and that all database tables have been created successfully by running the SQL initialization script. Verify that you can see the bonds, results, and history tables in the Supabase dashboard. Test the database connection by adding a test bond through the application interface and confirming it appears in the Supabase table. Verify that your environment variables are correctly configured in the .env.local file with valid credentials.

### Dependencies and Build Verification

Run `npm install` to ensure all dependencies are properly installed and that there are no unresolved version conflicts. Execute `npm run build` to create a production-optimized build and verify that the build completes without errors. Review the build output to confirm that there are no warnings or deprecated dependencies that need to be addressed.

### Security Audit

Ensure that your Supabase anonymous key is correctly restricted to only allow the operations required by this application. Review your .env.local file and confirm that no sensitive information or private keys have been committed to version control. Verify that your .gitignore file is properly configured and that environment files are excluded from the repository.

## Production Deployment Steps

### Option 1: Deploy to Vercel (Recommended)

Vercel is the official platform for deploying Next.js applications and provides automatic optimization and scaling. Begin by creating a free account at https://vercel.com if you do not already have one. Connect your GitHub repository by clicking the New Project button and authorizing Vercel to access your repositories.

Select the for-your-appointment repository from your GitHub account. Vercel will automatically detect that this is a Next.js project and configure the build settings appropriately. You do not need to modify the default build settings unless you have custom requirements.

In the Environment Variables section of the Vercel project settings, add both NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY with their corresponding values from your Supabase project. These values must match exactly the values in your .env.local file.

Click the Deploy button to initiate the deployment process. Vercel will automatically build your application and deploy it to a live URL within approximately two to three minutes. Once the deployment completes successfully, you will receive a unique URL where your application is accessible to the public.

### Option 2: Deploy to AWS (Self-Hosted)

For organizations requiring more control or specific AWS integration, you can deploy the application using AWS services. Begin by creating an AWS account if you do not have one already. Use AWS CodeDeploy to set up continuous deployment from your GitHub repository.

Create an EC2 instance with Ubuntu 22.04 LTS as the operating system and select an instance type with at least 1GB of RAM, such as t3.micro. Connect to your instance via SSH and install Node.js version 18 or later along with npm and git for repository management.

Clone your repository onto the instance and install all dependencies using npm install. Create an .env.local file on the server with your Supabase credentials. Build the application using npm run build and then start the production server using npm start.

For production deployments, it is strongly recommended to use a process manager such as PM2 to keep the Node.js application running continuously. Install PM2 globally, then run `pm2 start npm --name "for-your-appointment" -- start` to start the application as a background service.

Configure an Elastic Load Balancer in front of your EC2 instance to distribute traffic and provide automatic failover capabilities. Set up auto-scaling groups to automatically adjust the number of instances based on traffic demand.

### Option 3: Deploy to DigitalOcean

DigitalOcean provides a straightforward deployment option through their App Platform, which is designed for developers seeking simplicity without the complexity of AWS. Create a new App in the DigitalOcean App Platform and connect your GitHub repository.

Select Next.js as the application type and allow DigitalOcean to automatically configure the build and deployment settings. Add your Supabase environment variables in the App Platform's environment variables section.

DigitalOcean will automatically build and deploy your application on each commit to your repository. You will receive a public URL where your application is accessible immediately upon successful deployment.

## Post-Deployment Verification

After deploying to your chosen platform, verify that the application is functioning correctly in the production environment. Access the live URL in your web browser and confirm that the dashboard loads without errors. Navigate to each page (Add Bond, Upload Result) and test the core functionality by adding a test bond and uploading a test PDF.

Monitor your deployment for any errors by checking the platform's logging dashboard. In Vercel, access the Logs tab in your project settings. For AWS deployments, monitor CloudWatch logs. For DigitalOcean, use the built-in log viewer in the App Platform dashboard.

Verify that your Supabase database is receiving data correctly by checking the tables in the Supabase dashboard. Confirm that bonds added through the production application appear in the bonds table and that uploaded PDFs are being processed correctly.

## Ongoing Maintenance

### Regular Backups

Supabase provides automatic daily backups for paid plans. If using the free tier, manually backup your database weekly by exporting it through the Supabase dashboard. To export your data, navigate to Settings in your Supabase project, select the Backups tab, and download a backup file. Store backup files securely in multiple locations.

### Database Maintenance

Monitor your Supabase usage to ensure you remain within your plan's limits. Clean up old or test data periodically by removing obsolete bond entries or historical results from the database. The application stores all data indefinitely by default, which can lead to performance degradation over time as the database grows.

### Security Updates

Keep your dependencies up to date by running `npm outdated` monthly to identify packages with available updates. Run `npm update` to install minor and patch updates, but test thoroughly before deploying updates to production. Review security advisories in your dependencies using `npm audit` and address any critical vulnerabilities immediately.

## Troubleshooting Production Issues

### Application Not Loading

If your application fails to load after deployment, first verify that your environment variables have been correctly configured on the hosting platform. Many deployment failures occur due to missing or incorrectly formatted Supabase credentials. Check the application logs to identify the specific error preventing the application from starting.

### Slow Database Queries

If your dashboard is loading slowly, your database may have accumulated too many historical records. Access the Supabase SQL editor and run a query to count records in each table. If the results table contains more than 100,000 records, consider archiving old results to a separate table or removing entries older than one year.

### PDF Processing Failures

If PDF uploads are failing, verify that your test PDF contains properly formatted 6-digit numbers. The application's OCR fallback may take significantly longer than text extraction, so allow up to 30 seconds for processing to complete. If the issue persists, download the official draw result PDF directly from the lottery authority and verify that it contains the expected format.

### Database Connection Errors

If you receive "Failed to connect to database" errors, verify that your Supabase project status shows as Active in the Supabase dashboard. Check that your anonymous key has not been rotated or regenerated. Verify your internet connection and firewall settings are not blocking connections to Supabase's servers.

## Performance Optimization

To optimize application performance in production, enable caching headers by configuring your server to cache static assets for extended periods. In Vercel, this is configured automatically. For self-hosted deployments, configure your reverse proxy or CDN to cache static files.

Monitor database query performance using Supabase's query analytics to identify slow queries. Add indexes to frequently queried fields if they are not already indexed. Consider implementing pagination for large result sets to reduce the data transferred per request.

Enable compression on your server to reduce file sizes transmitted to users. Configure your hosting platform's auto-scaling settings to ensure your application can handle traffic spikes during major draw announcements or marketing campaigns.

## Rollback Procedure

In case of critical issues with a deployed version, rollback to the previous working version as follows. For Vercel deployments, navigate to the Deployments tab in your project settings, identify the last known good deployment, and click the three-dot menu to redeploy that version.

For AWS deployments using CodeDeploy, navigate to the CodeDeploy console and select your application. Click the Revisions tab, select the previous working revision, and click Deploy Now to rollback to that version.

For DigitalOcean deployments, access the App Platform console, click on your application, navigate to the Deployments tab, and click the three-dot menu on the previous working deployment to redeploy it.

Always keep detailed deployment notes documenting which version corresponds to which production release. This enables faster identification and recovery from issues that may arise in production.
