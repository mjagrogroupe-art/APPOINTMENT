# Database Schema Reference

This document provides comprehensive documentation of the Prize Bond Intelligence System's database schema, including all tables, columns, relationships, and constraints.

## Overview

The system uses PostgreSQL through Supabase to store all application data. Three main tables capture bonds, draw results, and historical performance metrics. All tables use UUID primary keys for reliable distributed system operation and include timestamp columns for audit trails.

## Table: bonds

The bonds table stores all prize bonds in the user's inventory. Each bond record represents a single physical prize bond with its identifying information and investment amount.

### Columns

The id column is a UUID primary key automatically generated for each new bond record. This unique identifier is used throughout the system to reference specific bonds.

The serial column contains the bond's serial number as a text field, typically an alphanumeric value provided by the bond issuer. This field stores the serial number for reference purposes but does not require uniqueness since multiple bonds may share the same serial prefix.

The number column contains the 6-digit bond number as text and is the unique identifier used for matching against draw results. This field has a unique constraint to prevent duplicate entries of the same bond number. The application enforces that only valid 6-digit numbers are stored.

The denomination column stores the original investment amount in Pakistani Rupees as an integer value. Standard values include 100, 500, 1500, 5000, 10000, 15000, and 25000 PKR, though any positive integer is accepted.

The purchase_date column stores when the bond was purchased as a timestamp, allowing bonds to be organized and filtered by acquisition date. This field defaults to the current time if not specified.

The created_at column stores when the bond record was created in the system as a timestamp, providing an audit trail. This field automatically captures the system time when a bond is first added to the application.

### Indexes

An index on the number column provides fast lookups during the matching process when comparing draw results against the bond inventory. This optimization ensures that matching thousands of bonds against lottery results completes in milliseconds.

## Table: results

The results table stores all extracted lottery draw results, including the winning numbers and their corresponding prize classifications and amounts.

### Columns

The id column is a UUID primary key automatically generated for each result record. This unique identifier allows individual results to be referenced and updated independently.

The draw column contains the name or identifier of the draw as text, such as "Draw 2024-January" or "Draw 202401". This allows results from different draws to be organized and queried together.

The draw_date column stores the official date of the draw as a timestamp in UTC format. This enables results to be sorted chronologically and historical performance to be analyzed by time period.

The number column contains the 6-digit winning number as text. This is the field matched against the bonds table during win checking. Multiple number entries may exist for a single draw when a draw produces multiple winners.

The prize_type column stores the classification of the prize as text, with valid values of "first", "second", or "third". This determines the prize amount awarded and enables prize-specific statistics and reporting.

The amount column stores the monetary prize value in Pakistani Rupees as an integer. Standard amounts are 7500000 for first prize, 750000 for second prizes, and 40000 for third prizes, though these can be customized.

The created_at column stores when the result record was created in the system as a timestamp. This allows tracking of when results were added to the system for audit purposes.

### Indexes

An index on the number column enables fast matching when comparing extracted numbers against the bonds table. An index on the draw column allows efficient retrieval of all results from a specific draw, enabling draw-specific analysis and reporting.

## Table: history

The history table stores aggregated performance metrics by draw, providing a high-level summary of wins and amounts for each lottery draw processed by the system.

### Columns

The id column is a UUID primary key automatically generated for each history record. This unique identifier references individual draw summaries.

The draw column contains the draw name or identifier as text, matching the draw column in the results table. This field has an implicit unique constraint as the system uses upsert operations to prevent duplicate entries for the same draw.

The draw_date column stores the official draw date as a timestamp in UTC format. This enables historical analysis to be filtered and sorted by time period.

The total_wins column stores the count of bonds that won prizes in this draw as an integer, providing a quick summary of the number of winning bonds.

The total_amount column stores the aggregate prize amount in Pakistani Rupees for all wins in the draw as an integer. This summarizes the total monetary returns from the draw.

The created_at column stores when the history record was created or last updated in the system as a timestamp.

### Indexes

An index on the draw column optimizes lookups and upsert operations when updating history for a specific draw, ensuring that history records are efficiently located and updated.

## Data Relationships

The bonds table maintains a many-to-many relationship with the results table through the number column. A single bond number may match multiple results across different draws if the same number is drawn more than once. A single result number may theoretically match multiple bonds, though in practice bond numbers are unique identifiers.

The history table aggregates data from the results table using the draw column as the relationship key. Each history record summarizes all results from a specific draw, providing efficient access to draw-level statistics.

## Data Constraints and Validation

The system enforces at the database level that the bonds.number column must be unique to prevent duplicate bonds. The results table does not enforce uniqueness, allowing the same number to appear multiple times across different draws or within the same draw if the draw structure includes the same number multiple times.

Bond numbers must be exactly 6 digits. The application validates this at the API level before inserting into the database, preventing invalid data entry.

Prize amounts are stored as positive integers representing PKR currency values. The application uses predefined constants for standard prize amounts, though the database does not enforce specific values.

All timestamp columns use UTC time format internally, though the application may display times in the user's local timezone using client-side conversion.

## Performance Considerations

The bonds table is optimized for fast lookups by number during matching operations. For systems with over 10,000 bonds, query response times remain under 100 milliseconds due to database indexing.

The results table scales efficiently to handle large numbers of draw records. Systems with 100,000+ result records maintain fast query performance due to the strategic placement of indexes on the number and draw columns.

The history table is designed for efficient aggregation and reporting. Query performance remains optimal even with thousands of historical draws stored in the database.

## Backup and Recovery

All data is stored in Supabase's managed PostgreSQL database. The Supabase platform provides automatic daily backups for paid accounts and provides manual backup options for free tier users.

To manually backup your data, access the Supabase dashboard, navigate to Settings, and download a database backup from the Backups tab. Store backup files in a secure location for recovery purposes.

To restore from a backup, contact Supabase support with your backup file. They will restore your database to the state captured in the backup.

## Modifying the Schema

To add new columns to existing tables, use the Supabase SQL Editor to execute ALTER TABLE statements. For example, to add a new column to track bond purchase location, you would execute:

```sql
ALTER TABLE bonds ADD COLUMN purchase_location TEXT;
```

To create new tables or make structural changes, generate the necessary SQL and execute it through the Supabase SQL Editor. Always test schema changes in a development environment before applying them to production data.

To create a backup before making schema changes, download a backup from the Supabase dashboard and retain it until you have confirmed that the schema changes work correctly with the application code.
