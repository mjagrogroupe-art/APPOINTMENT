# Lite Image Generation Service

This repository contains a minimal FastAPI application that implements a tiny
image generation API with daily usage quotas. It is designed for scenarios
where you want to provide a controlled image generation capability to a few
users without incurring significant infrastructure or API costs.

## Features

- **Two users**: Alice and Bob, each with their own API key.
- **Daily quota**: Default of five images per user per day, enforced server‑side.
- **Endpoints**:
  - `POST /api/generate`: produce an image from a text prompt.
  - `GET /api/status`: view your remaining quota and last generation time.
  - `GET /api/history`: fetch a list of your recent generations.
  - `GET /images/{filename}`: retrieve a generated image.
  - `POST /admin/reset-quota`: reset a user's counter (admin key required).
  - `GET /admin/users`: list users and their usage (admin key required).
- **Storage**: SQLite for metadata, local filesystem for images.
- **Image generation**: uses the Fal.ai community API if a `FAL_API_KEY` is
  provided; otherwise falls back to Pillow to render the prompt on a blank
  background.
- **Low cost**: runs happily on a free Railway/Render plan or a small VPS.

## Quickstart

1. **Install dependencies**:

   ```bash
   pip install -r requirements.txt
   ```

2. **Initialise the database**:

   ```bash
   cd lite-imagegen
   python init_db.py
   ```

   This will create `lite_imagegen.db` and insert two users with the API keys
   `sk_alice_XXXXXXXXXXXX` and `sk_bob_XXXXXXXXXXXX`.

3. **Run the API server**:

   ```bash
   uvicorn main:app --reload --port 8000
   ```

   The service will be available at `http://localhost:8000`. If you set
   the `ADMIN_KEY` environment variable, use that for admin routes; otherwise
   the default is `admin123`.

4. **Generate an image**:

   ```bash
   curl -X POST http://localhost:8000/api/generate \
     -H "Authorization: Bearer sk_alice_XXXXXXXXXXXX" \
     -H "Content-Type: application/json" \
     -d '{"prompt": "a blue bird on a tree"}'
   ```

   By default, the service will return a JSON payload with the URL of your
   generated image and remaining quota. If you did not supply a Fal.ai API key
   (`FAL_API_KEY`), the image will simply contain your prompt drawn on a
   white background.

5. **Check status and history**:

   ```bash
   curl http://localhost:8000/api/status -H "Authorization: Bearer sk_alice_XXXXXXXXXXXX"
   curl http://localhost:8000/api/history?limit=5&days=3 -H "Authorization: Bearer sk_alice_XXXXXXXXXXXX"
   ```

6. **Admin actions** (optional):

   Set `ADMIN_KEY` in your environment before starting the server. Then you can
   reset usage or list users:

   ```bash
   curl -X POST http://localhost:8000/admin/reset-quota \
     -H "X-Admin-Key: your_admin_key" -d "user_id=1"

   curl http://localhost:8000/admin/users -H "X-Admin-Key: your_admin_key"
   ```

## Deployment

To deploy, connect this repo to a free tier hosting provider such as
Railway.app or Render.com. The service is small enough to run within their
free quotas. Use the `PORT` environment variable provided by the platform,
and ensure that `DB_PATH` points to a persistent volume or use an external
database if required.

## Extending

- Swap out the Pillow fallback with your preferred image generation model.
- Adjust the schema to support additional users or more complex quota
  strategies.
- Add authentication middleware, rate limiting, or logging as needed.

Enjoy your tiny image generation service!