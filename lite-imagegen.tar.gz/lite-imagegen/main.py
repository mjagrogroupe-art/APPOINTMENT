"""
Lite Image Generation Service

This FastAPI application implements a minimal image generation service with user
authentication and per‑day quotas. It exposes endpoints to generate images,
check quota status, view generation history, reset quotas, and list users. All
state is stored in a local SQLite database and generated images are saved to
disk. The system is deliberately simple—two hard‑coded users share a tiny
database and a lightweight image generator that uses Pillow to render the
prompt into a PNG. The aim is to keep infrastructure costs near zero while
still providing a functional API that mirrors common patterns found in paid
image‑generation services.

Usage:

    # Initialise the database once
    python init_db.py

    # Run the API
    uvicorn main:app --reload --port 8000

Configuration:

Set an environment variable ``ADMIN_KEY`` to control access to admin routes.
Optionally set ``FAL_API_KEY`` to enable remote image generation via the
Fal.ai community API; if unset, a Pillow fallback will be used.

This file intentionally contains extra comments to aid maintenance and
extensibility. Feel free to remove them if you deploy this in a production
setting.
"""

import os
import sqlite3
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Tuple

from fastapi import Depends, FastAPI, Header, HTTPException, Query, Request, status
from fastapi.responses import FileResponse
from pydantic import BaseModel

# Third‑party libraries used for optional remote generation
import requests
from PIL import Image, ImageDraw, ImageFont


# Paths and constants
DB_PATH = os.environ.get("DB_PATH", "lite_imagegen.db")
IMAGES_DIR = os.environ.get("IMAGES_DIR", "images")
ADMIN_KEY = os.environ.get("ADMIN_KEY", "admin123")

# Make sure the images directory exists
os.makedirs(IMAGES_DIR, exist_ok=True)

app = FastAPI(title="Lite Image Generation Service")


class QuotaChecker:
    """Encapsulates quota logic and user lookup."""

    @staticmethod
    def get_db_connection() -> sqlite3.Connection:
        """Open a SQLite connection with row factory set."""
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        return conn

    @staticmethod
    def get_user_by_api_key(api_key: str) -> Optional[Dict]:
        """Return user record corresponding to the given API key or None."""
        conn = QuotaChecker.get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE api_key = ? AND is_active = 1", (api_key,))
        user = cursor.fetchone()
        conn.close()
        return dict(user) if user else None

    @staticmethod
    def get_today_date() -> str:
        """Return today's date in UTC as YYYY‑MM‑DD."""
        return datetime.now(timezone.utc).date().isoformat()

    @staticmethod
    def get_usage_for_today(user_id: int) -> int:
        """Return the number of images generated today by the given user."""
        conn = QuotaChecker.get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT generation_count FROM daily_usage WHERE user_id = ? AND date = ?",
            (user_id, QuotaChecker.get_today_date()),
        )
        row = cursor.fetchone()
        conn.close()
        return row[0] if row else 0

    @staticmethod
    def check_quota(user_id: int, daily_limit: int) -> Tuple[bool, Dict]:
        """Check if the user can generate another image today.

        Returns a tuple of (can_generate, info_dict).
        """
        used = QuotaChecker.get_usage_for_today(user_id)
        can_generate = used < daily_limit
        # Compute time until next midnight UTC
        now = datetime.now(timezone.utc)
        tomorrow = (now + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
        delta = tomorrow - now
        hours, remainder = divmod(int(delta.total_seconds()), 3600)
        minutes = remainder // 60
        info = {
            "quota_limit": daily_limit,
            "quota_used": used,
            "quota_remaining": max(0, daily_limit - used),
            "quota_resets_in": f"{hours}h {minutes}m",
        }
        return can_generate, info

    @staticmethod
    def increment_quota(user_id: int) -> None:
        """Increment the daily usage counter for the user."""
        conn = QuotaChecker.get_db_connection()
        cursor = conn.cursor()
        today = QuotaChecker.get_today_date()
        cursor.execute(
            "UPDATE daily_usage SET generation_count = generation_count + 1 WHERE user_id = ? AND date = ?",
            (user_id, today),
        )
        if cursor.rowcount == 0:
            cursor.execute(
                "INSERT INTO daily_usage (user_id, date, generation_count) VALUES (?, ?, 1)",
                (user_id, today),
            )
        conn.commit()
        conn.close()


async def get_current_user(authorization: str = Header(None)) -> Dict:
    """FastAPI dependency to extract and validate user from Authorization header."""
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Missing or invalid Authorization header")
    api_key = authorization[len("Bearer "):]
    user = QuotaChecker.get_user_by_api_key(api_key)
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid API key")
    return user


class GenerateRequest(BaseModel):
    prompt: str
    width: Optional[int] = 512
    height: Optional[int] = 512
    num_inference_steps: Optional[int] = 20  # accepted but unused in default implementation


@app.post("/api/generate")
async def generate_image(request: GenerateRequest, current_user: Dict = Depends(get_current_user)):
    """Generate an image based on the provided prompt. Enforces daily quotas."""
    user_id = current_user["id"]
    daily_limit = current_user.get("daily_limit", 5)
    # Check quota
    can_generate, quota_info = QuotaChecker.check_quota(user_id, daily_limit)
    if not can_generate:
        raise HTTPException(status_code=status.HTTP_429_TOO_MANY_REQUESTS, detail={
            "status": "quota_exceeded",
            "message": f"Daily limit ({daily_limit}) reached",
            **quota_info,
        })
    # Generate image
    try:
        image_data, filename = await generate_image_impl(request.prompt, user_id, request.width, request.height)
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail={
            "status": "error",
            "message": str(e),
            "error_code": "GENERATION_FAILED",
        })
    # Increment quota and log history
    QuotaChecker.increment_quota(user_id)
    conn = QuotaChecker.get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO generation_history (user_id, image_url, prompt, image_path, status) VALUES (?, ?, ?, ?, 'success')",
        (user_id, f"/images/{filename}", request.prompt, filename),
    )
    conn.commit()
    conn.close()
    # Compute updated quota info
    _, updated_quota = QuotaChecker.check_quota(user_id, daily_limit)
    # Response
    return {
        "status": "success",
        "image_url": f"/images/{filename}",
        "image_id": filename.split(".")[0],
        "generated_at": datetime.now(timezone.utc).isoformat(),
        **updated_quota,
    }


@app.get("/api/status")
async def get_status(current_user: Dict = Depends(get_current_user)):
    """Return quota status and last generation timestamp for the current user."""
    user_id = current_user["id"]
    daily_limit = current_user.get("daily_limit", 5)
    can_generate, quota_info = QuotaChecker.check_quota(user_id, daily_limit)
    conn = QuotaChecker.get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT generated_at FROM generation_history WHERE user_id = ? ORDER BY generated_at DESC LIMIT 1",
        (user_id,),
    )
    row = cursor.fetchone()
    conn.close()
    last_gen = row[0] if row else None
    return {
        "user": current_user["username"],
        "today_date": QuotaChecker.get_today_date(),
        "last_generation": last_gen,
        **quota_info,
    }


@app.get("/api/history")
async def get_history(
    limit: int = Query(10, ge=1, le=100),
    days: int = Query(7, ge=1, le=365),
    current_user: Dict = Depends(get_current_user),
):
    """Return a list of the user's recent image generation events.

    Parameters
    ----------
    limit: number of records to return (default 10)
    days: number of days to look back (default 7)
    """
    user_id = current_user["id"]
    cutoff_date = (datetime.now(timezone.utc) - timedelta(days=days)).date().isoformat()
    conn = QuotaChecker.get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT image_path, prompt, generated_at, status
        FROM generation_history
        WHERE user_id = ? AND DATE(generated_at) >= ?
        ORDER BY generated_at DESC
        LIMIT ?
        """,
        (user_id, cutoff_date, limit),
    )
    rows = cursor.fetchall()
    conn.close()
    history = [
        {
            "image_id": row[0].split(".")[0],
            "prompt": row[1],
            "generated_at": row[2],
            "image_url": f"/images/{row[0]}",
            "status": row[3],
        }
        for row in rows
    ]
    return {
        "user": current_user["username"],
        "total_generations": len(history),
        "history": history,
    }


@app.get("/images/{filename}")
async def serve_image(filename: str):
    """Serve an image file from the images directory."""
    path = os.path.join(IMAGES_DIR, filename)
    if not os.path.isfile(path):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Image not found")
    return FileResponse(path)


def verify_admin_key(admin_key: str) -> None:
    """Raise 401 if the provided admin key is incorrect."""
    if admin_key != ADMIN_KEY:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid admin key")


@app.post("/admin/reset-quota")
async def admin_reset_quota(
    user_id: int,
    admin_key: str = Header(None, alias="X-Admin-Key"),
):
    """Reset the given user's usage counter for today."""
    verify_admin_key(admin_key)
    conn = QuotaChecker.get_db_connection()
    cursor = conn.cursor()
    today = QuotaChecker.get_today_date()
    # Remove the row or set count to zero
    cursor.execute(
        "DELETE FROM daily_usage WHERE user_id = ? AND date = ?",
        (user_id, today),
    )
    conn.commit()
    conn.close()
    return {
        "status": "success",
        "user_id": user_id,
        "quota_reset": True,
        "new_count": 0,
    }


@app.get("/admin/users")
async def admin_list_users(admin_key: str = Header(None, alias="X-Admin-Key")):
    """List all users with their quota information for today."""
    verify_admin_key(admin_key)
    conn = QuotaChecker.get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, username, daily_limit, created_at, is_active FROM users")
    users = cursor.fetchall()
    result: List[Dict] = []
    for user in users:
        uid = user[0]
        limit = user[2]
        used = QuotaChecker.get_usage_for_today(uid)
        result.append(
            {
                "id": uid,
                "username": user[1],
                "daily_limit": limit,
                "today_usage": used,
                "created_at": user[3],
                "is_active": bool(user[4]),
            }
        )
    conn.close()
    return {"users": result}


async def generate_image_impl(prompt: str, user_id: int, width: int = 512, height: int = 512) -> Tuple[bytes, str]:
    """Create an image for the given prompt.

    This function first attempts to call the Fal.ai API if an API key is present
    in the environment (``FAL_API_KEY``). If that fails or no key is set, a
    fallback generator uses Pillow to render the prompt as text on a plain
    background. This ensures deterministic behaviour even in offline
    environments.
    """
    # Try Fal.ai if API key is provided
    fal_api_key = os.environ.get("FAL_API_KEY")
    if fal_api_key:
        try:
            response = requests.post(
                "https://queue.fal.run/fal-ai/fast-sdxl",
                headers={"Content-Type": "application/json", "Authorization": f"Key {fal_api_key}"},
                json={
                    "prompt": prompt,
                    "image_size": f"{width}x{height}",
                    "num_inference_steps": 10,
                    "guidance_scale": 7.5,
                },
                timeout=60,
            )
            if response.status_code == 200:
                data = response.json()
                # Fal.ai returns a list of image URLs
                image_url = data.get("images", [{}])[0].get("url")
                if image_url:
                    img_data = requests.get(image_url).content
                    # Save file
                    filename = _generate_filename(user_id)
                    path = os.path.join(IMAGES_DIR, filename)
                    with open(path, "wb") as f:
                        f.write(img_data)
                    return img_data, filename
        except Exception:
            # Ignore errors and fall back
            pass
    # Fallback: generate a simple image with text
    img = Image.new("RGB", (width, height), color=(255, 255, 255))
    draw = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype("DejaVuSans.ttf", 20)
    except Exception:
        font = ImageFont.load_default()
    text = prompt[:100] + ("..." if len(prompt) > 100 else "")
    # Compute bounding box for the text. Pillow 10+ deprecates `textsize` and `getsize`,
    # so we use `textbbox` which returns (left, top, right, bottom).
    bbox = draw.textbbox((0, 0), text, font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]
    x = (width - text_width) // 2
    y = (height - text_height) // 2
    draw.text((x, y), text, fill=(0, 0, 0), font=font)
    # Save file
    filename = _generate_filename(user_id)
    path = os.path.join(IMAGES_DIR, filename)
    img.save(path)
    # Return bytes
    with open(path, "rb") as f:
        data = f.read()
    return data, filename


def _generate_filename(user_id: int) -> str:
    """Generate a unique filename for an image based on date and timestamp."""
    timestamp = int(datetime.now(timezone.utc).timestamp())
    date_part = datetime.now(timezone.utc).strftime("%Y%m%d")
    return f"{date_part}_{user_id}_{timestamp}.png"
