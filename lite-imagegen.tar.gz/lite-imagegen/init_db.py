"""
Database initialisation script for the Lite Image Generation Service.

Running this module will create the SQLite database with the necessary
tables and insert two demo users (Alice and Bob) with fixed API keys. If
the database already exists, it will be replaced. Invoke this script
before running the API server for the first time.

Usage:

    python init_db.py

The script reads ``DB_PATH`` from the environment if set. It writes
``lite_imagegen.db`` by default.
"""

import os
import sqlite3
from datetime import datetime

# Determine DB path
DB_PATH = os.environ.get("DB_PATH", "lite_imagegen.db")

# Remove existing database if present
if os.path.exists(DB_PATH):
    os.remove(DB_PATH)

# Connect to new database
conn = sqlite3.connect(DB_PATH)
conn.row_factory = sqlite3.Row
cursor = conn.cursor()

# Create tables
cursor.executescript(
    """
    CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        api_key TEXT UNIQUE NOT NULL,
        daily_limit INTEGER NOT NULL DEFAULT 5,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        is_active BOOLEAN NOT NULL DEFAULT 1
    );

    CREATE TABLE daily_usage (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        date DATE NOT NULL,
        generation_count INTEGER NOT NULL DEFAULT 0,
        last_reset TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id),
        UNIQUE(user_id, date)
    );

    CREATE TABLE generation_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        image_url TEXT NOT NULL,
        prompt TEXT NOT NULL,
        generated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        image_path TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'success',
        error_message TEXT,
        FOREIGN KEY(user_id) REFERENCES users(id)
    );
    """
)

# Insert hard‑coded users
users = [
    ("alice", "sk_alice_XXXXXXXXXXXX", 5),
    ("bob", "sk_bob_XXXXXXXXXXXX", 5),
]
cursor.executemany(
    "INSERT INTO users (username, api_key, daily_limit) VALUES (?, ?, ?)", users
)
conn.commit()
conn.close()

print(f"Database initialised at {DB_PATH} with users: {[u[0] for u in users]}")