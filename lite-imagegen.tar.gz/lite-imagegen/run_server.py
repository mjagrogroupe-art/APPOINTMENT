"""
Simple wrapper to run the FastAPI application using uvicorn without relying on
the CLI. This sidesteps certain import bugs observed when running
``uvicorn main:app`` directly via the command line under Python 3.13.

Usage:

    python run_server.py

The script reads environment variables for host and port, defaulting to
``0.0.0.0`` and ``8000`` respectively.
"""

import os

import uvicorn

from main import app


def main() -> None:
    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", "8000"))
    uvicorn.run(app, host=host, port=port)


if __name__ == "__main__":
    main()